public class SubClass1 extends SuperClass1
{
   /**
      Constructor
   */

   public SubClass1()
   {
      System.out.println("This is the " +
                 "subclass constructor.");
   }
}
