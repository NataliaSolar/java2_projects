/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectangledemo;
import java.util.*;
/**
 *
 * @author alexandra.vaschillo
 */
public class Rectangle implements Cloneable{
    protected double length;
    protected double width;
    private int label;
    /**
     * No-argument constructor
     */
    public Rectangle()
    {
        System.out.println("Calling non-arg Rectangle constructor");
        Random r = new Random();
        label = r.nextInt(100)+1;
        length=1;
        width=1;
    }
     public Rectangle(double l, double w) throws IllegalArgumentException
     {
         System.out.println("Calling Rectangle constructor");
         Random r = new Random();
         label = r.nextInt(100)+1;
         if(l<0) throw new IllegalArgumentException ("Negative length");
         if(w<0) throw new IllegalArgumentException ("Negative width");
         length = l;
         width= w;
     }
     public Rectangle(Rectangle obj)
     {
         this.length = obj.length;
         width = obj.width;
         this.label = obj.label;
     }
    /**
     * Acessor method returns length field
     * @return returns length field 
     */
    public double getLength()
    {
        return length;
    }
    public double getWidth()
    {
        return width;
    }
    /**
     * Mutator for length field
     * @param l  takes length value as a parameter
     */
    public void setLength(double l)throws IllegalArgumentException 
    {
        if(l<0) throw new IllegalArgumentException ("Negative length");
        length = l;
    }
    public void setWidth(double w)throws IllegalArgumentException 
    {
        if(w<0) throw new IllegalArgumentException ("Negative width");
        width = w;
    }
    @Override public String toString()
    {
        String s = "Width: "+width+" Length: "+length;
        return s;
    }
    @Override public Rectangle clone()
    {
        try{
        return (Rectangle)super.clone();
        }
        catch (CloneNotSupportedException e)
        {
            return null;
        }
    }
    @Override public boolean equals(Object otherObj)
    {
        if(otherObj == null) 
            return false;
        else if(getClass( ) != otherObj.getClass( )) // makig  sure the object we got is of the aame class as the one we are in 
            return false;
        else
        {
        Rectangle otherR = (Rectangle)otherObj;
        return this.length == otherR.length && this.width == otherR.width;
        }

    }
}
