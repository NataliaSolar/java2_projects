/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectangledemo;
import java.util.Arrays;

/**
 *
 * @author alexandra.vaschillo
 */
public class RectangleDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
     /*   int a = 55;
        int b = 99;
      //  try{
            Rectangle r1 = new Rectangle(a, b);
        Box box = new Box(70, r1);
        System.out.println(box.toString());
        r1.setLength(1);
        System.out.println(box.toString());
     */
     int[] a = {1, 2, 3};
     //int[] c = a;
     // default clone() method
     int[] b = a.clone();
     //a[0]=55;
     ColoredBox b1 = new ColoredBox(5, 8, 19, a);
     ColoredBox b2 = new ColoredBox(5, 18, 19, b);
     ColoredBox b3 = b1.clone();
     b1.setColor(8, 8, 8);
     System.out.println(Arrays.toString(a));
     System.out.println(Arrays.toString(b));
     
     System.out.println(b1.toString());
     System.out.println(b2.toString());
     System.out.println(b3.toString());
     
     Rectangle r = (Rectangle) new ColoredBox();
     System.out.println(r.toString());
     //ColoredBox cb = (ColoredBox)new Rectangle(r);
     //double h = cb.getHeight();
     ColoredBox b4 = new ColoredBox(5, 18, 19, a);
     ColoredBox b5 = new ColoredBox(5, 18, 19, b);
     if(b4.equals(b5)) System.out.println("Equal!!");
     else System.out.println("NOT Equal!!");
     
     
    }
    
}
