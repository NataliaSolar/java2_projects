// This program shows variable initialization.

public class Initialize
{
   public static void main(String[] args)
   {
      int month = 2, days = 28;

      System.out.println("Month " + month + " has " +
                         days + " days.");
   }
}
