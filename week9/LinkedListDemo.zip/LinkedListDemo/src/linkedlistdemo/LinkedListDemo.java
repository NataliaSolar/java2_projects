/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlistdemo;

/**
 *
 * @author alexandra.vaschillo
 */
public class LinkedListDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LinkedList list = new LinkedList();
        list.print();
        list.addToStart(1);
        list.addToEnd(10);
        System.out.println(list);
        list.add(5, 1);
        list.add(0, 0);
        System.out.println(list);
        System.out.println(list.remove(3));
        System.out.println(list);
        list.add(20, 1);
        list.add(22, 1);
        list.printList();
        list.printBackwards();
    }
    
}
