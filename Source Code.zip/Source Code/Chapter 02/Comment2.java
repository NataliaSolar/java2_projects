/* 
   PROGRAM: Comment2.java
   Written by Herbert Dorfmann
   This program calculates company payroll
*/

public class Comment2
{
   public static void main(String[] args)      
   {
       double payRate;     // Holds the hourly pay rate
       double hours;       // Hours holds the hours worked
       int employeeNumber; // Holds the employee number

       // The Remainder of This Program is Omitted.
   }
}

