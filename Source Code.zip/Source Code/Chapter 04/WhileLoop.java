/**
   This program demonstrates the while loop.
*/

public class WhileLoop
{
   public static void main(String [] args)
   {
      int number = 1;

      while (number <= 5)
      {
         System.out.println("Hello");
         number++;
      }

      System.out.println("That's all!");
   }
}
