/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlistdemo;

/**
 *
 * @author alexandra.vaschillo
 */
public class LinkedList {
       private class Node
    {
        int value;   
        Node next;             
        /**
           Constructor.            
           @param val The element to store in the node.
           @param n The reference to the successor node.
        */        
        Node(int val, Node n)
        {
            value = val;
            next = n;
        }       
        /**       
           Constructor. 
           @param val The element to store in the node.
        */       
        Node(int val)
        {
           // Call the other (sister) constructor.
           this(val, null);            
        }
     }
     
     private Node head;
     private Node last; 
     
     public LinkedList()
     {
         head = last = null;
     }
     public void addToEnd(int val)
     {
        if(last == null)
        {
           head = last = new Node(val); 
        }
        else
        {
         Node newNode = new Node(val);
         last.next = newNode;
         last = newNode;
        }
     }  
     public void addToStart(int val)
     {
        if(head == null)
        {
           head = last = new Node(val); 
        }
        else {
         Node newNode = new Node(val);
         newNode.next = head;
         head = newNode;
        }
     }
     public void add(int val, int index)
     {
         if(index>this.length() || index<0) throw new IllegalArgumentException("Index out of bounds");
         
         if(index==0) 
          {
                 if(head == null)
           {
              head = last = new Node(val); 
           }
           else {
            Node newNode = new Node(val);
            newNode.next = head;
            head = newNode;
            }
         }
         else if(index == this.length())
         {
                if(last == null)
           {
              head = last = new Node(val); 
           }
           else
           {
            Node newNode = new Node(val);
            last.next = newNode;
            last = newNode;
           } 
         }
         else
         {
         int count = 0;
         Node curr = head;
         while(count<index-1)
         {
            count++;
            curr = curr.next;
         }
         Node currNext = curr.next;
         Node tmp = new Node(val);
         curr.next = tmp;
         tmp.next = currNext;
        // if(index==0) head = tmp;
        // else if(index == this.length()-1) last = tmp;
         }
     }
     
     public int remove(int index)
     {
         if(index>this.length() || index<0) throw new IllegalArgumentException("Index out of bounds");
         if(index==0)
         {
             Node tmp = head;
             head = head.next;
             return tmp.value;
         }
         Node prev = head;
         Node cur = head.next;
         int count = 1;
         while(cur!=null && count<index)
         {
             prev = cur;
             cur = cur.next;
             count++;
         }
         prev.next = cur.next;
         if(cur == last) last = prev;
         return cur.value;
         
         
     }
     private void printBackRec(Node cur)
     {
        if(cur == null) return; // base case
         printBackRec(cur.next);
         System.out.print(cur.value+" ");
     }
     public void printBackwards()
     {
         printBackRec(head);
        System.out.print("\n");
     }
     public void printList()
     {
        printRec(head);
        System.out.print("\n");
     }
     private void printRec(Node cur)
     {
         if(cur == null) return; // base case
         System.out.print(cur.value+" ");
         printRec(cur.next);
     }
     public void print()
     {
         Node current = head;
         while(current!=null)
         {
             System.out.print(current.value+" ");
             current = current.next;
         }
     }
    public int length()
    {
        int count = 0;
         Node current = head;
         while(current!=null)
         {
             count++;
             current = current.next;
         } 
         return count;
    }
     @Override public String toString()
     {
         StringBuilder tmp = new StringBuilder();
         Node current = head;
         while(current!=null)
         {
             tmp.append(current.value+" ");
             current = current.next;
         }
         return tmp.toString();
     } 
}
